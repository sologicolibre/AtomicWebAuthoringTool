import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class ATOMICWEB04windows extends PApplet {


PImage imagen; // variable para la imagen del del programa
PImage menu; // variable para la imagen del menu
PImage logo; // variable para la imagen del logo
PImage help; // variable para la imagen de la ayuda
PFont font; // variable para cargar el tipo de fuente que usara el programa
//int c=0;
//int activav=1;
//int entrada=0; // variable que se usa para saber si se acava de abrir el programa
int nima; // numero de componentes (imagenes) a cargar en el entorno de programacion (background)
int xima; //guarda la posicion en X de cada componente (imagen) dentro del entorno de programacion (background)
int yima; //guarda la posicion en X de cada componente (imagen) dentro del entorno de programacion (background)
//int bm=0;
//int d=0;
//int j=-1;
int mx;// Posicion X del mouse al hacer click - indica el centro del menu
int my;// Posicion Y del mouse al hacer click - indica el centro del menu
int mm=-1; // Activa o desactiva mostrar el menu; 1=mostrar -1=oculto
int x=0; // guarda valor de X usado para dibujar la cuadricula(grid)
int y=0; // guarda valor de Y usado para dibujar la cuadricula(grid)
int inc=20; // valor que indica el espacio entre las lineas de la cuadricula(grid)
//int mox;
//int moy;
int six;// Logitud horizontal desde el centro de la imagen del menu 
int siy;// Logitud vertical desde el centro de la imagen del menu
//int px;
//int py;
int mhelp=0; // determina si muesta la ayuda o no; 1 = si
int mlogo=1; // determina si se muestra el logo o no; 1 = si
int inicio=0; // Determina si el click es cuando el menu esta activo; 0=no, 1=si
int xb1;//posicion X del boton 1
int yb1;//posicion Y del boton 1
int xb2;//posicion X del boton 2
int yb2;//posicion Y del boton 2
int xb3;//posicion X del boton 3
int yb3;//posicion Y del boton 3
int xb4;//posicion X del boton 4
int yb4;//posicion Y del boton 4
int xb5;//posicion X del boton 5
int yb5;//posicion Y del boton 5
int xb6;//posicion X del boton 6
int yb6;//posicion Y del boton 6
int xb7;//posicion X del boton 7
int yb7;//posicion Y del boton 7
int pbx=0;//posicion X del Background
int pby=0;//posicion Y del Background
int dragged=0; // indica si se esta draggeando con el mouse
int mdx; // indica la posicion en X del mouse al finalizar el dragging 
int mdy; // indica la posicion en Y del mouse al finalizar el dragging 
int click=0; // -1=primer click 1=segundo click
int nslash=0; // nuemro de slash en el path (ruta) de archivo
String[] minfo;// Guarda las posiciones del los objetos en el programa
String[] marcador;//marcador seleccionado para la aplicacion de Realidad Aumentada
String[] objeto;// Carga la direeccion del objeto 3D seleccionado para la aplicacion de Realidad Aumentada
String t; // guarda informacion temporal
String[] vmrl; // Carga direccion del marcador
//String name=""; //guarda el nombre del archivo del Objeto 3D
//String name2=""; //guarda el nombre del archivo del marcador
String[] lista; // guarda temporalmente la lista de los nombres de las carpetas en una ruta
String[] vmrlobject; // se usa como variable temporal para compiar en la carpeta Wrl el objeto 3D seleccionado 
//String[] command; // variable para usar comandos via shell
String[] lastex; //variable para guardar el nombre de la carpeta de la ultima textura usada
String textura; // guarda el nombre de la textura
String[] splitpath; // variable para extraer el nombre de un archivo deste una ruta
String urlvalidada;

String[] xmlconfig; // Carga archivo xml de configuracion en modo TXT

String patternurl; //guarda el nombre del archivo del marcador
String object3durl; //guarda el nombre del archivo del Objeto 3D
String pattern; //guarda el nombre del archivo del marcador
String object3d; //guarda el nombre del archivo del Objeto 3D
String speeds;//guarda el valor (en modo string) de la velocidad de rotacion Objeto 3D
String modelsizes;//guarda el valor (en modo string) del tama\u00f1o del objeto 3D
float speed;//guarda el valor de la velocidad de rotacion Objeto 3D
float modelsize;//guarda el valor del tama\u00f1o del objeto 3D

XMLElement xml; // Carga archivo xml de configuracion en modo XML

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public void setup() 
{

  size(screen.width, screen.height, P2D);
  font = loadFont("TheSans-Plain-12.vlw"); 
  textFont(font);
  menu = loadImage("menup.png");
  logo = loadImage("atomiclogo.png");
  help = loadImage("help.png");
  image(logo,(screen.width/2)-286, (screen.height/2)-191);
  six=(menu.width)/2;
  siy=(menu.height)/2;
  my=0;
  mx=0;

  xmlconfig = loadStrings("data/project/config.xml"); //lee el archivo XML en modo TXT

    xml = new XMLElement(this, "data/project/config.xml"); //lee el archivo XML en modo XML

    XMLElement kid = xml.getChild(0); // lee contnido de project
    int numSites = kid.getChildCount(); // lee contenido de module
    
    XMLElement subkid = kid.getChild(0);  //lee contenido pattern
    patternurl = subkid.getContent(); // pone contenido en variable
    
    subkid = kid.getChild(1);  //lee contenido 3d object
    object3durl = subkid.getContent(); // pone contenido en variable

    subkid = kid.getChild(2);  //lee tama\u00f1o objeto 3D
    modelsizes = subkid.getContent(); // pone contenido en variable
    modelsize = PApplet.parseFloat(modelsizes);
    
    subkid = kid.getChild(3);  //lee velociad rotacion objecto 3D
    speeds = subkid.getContent(); // pone contenido en variable
    speed = PApplet.parseFloat(speeds);

  //objeto = loadStrings("Wrl/bud_B.dat");
  //vmrl = loadStrings("Data/object_data_vrml");
  //name=objeto[0];
  //name2=vmrl[5];
     splitpath = splitTokens(patternurl, "/"); 
     nslash=(splitpath.length)-1; // determina la cantidad de slash en la ruta
     pattern = splitpath[nslash]; //se guarda el nombre del archivo seleccionado

     splitpath = splitTokens(object3durl, "/"); 
     nslash=(splitpath.length)-1; // determina la cantidad de slash en la ruta
     object3d = splitpath[nslash]; //se guarda el nombre del archivo seleccionado

 
}//Fin Setup


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



public void menu()
{

  image(menu,mx-six, my-siy, menu.width/1, menu.height/1);

  // muestra info si el cursor esta sobre algun boton del menu 
  infomenu();
  //

}//fin Ventana



//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


public void help()
{

  image(help,(screen.width/2)-286, (screen.height/2)-191);
//delay(4000);
//mhelp=0;


}//fin Ventana



//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public void infomenu(){
  
    fill(0); // Determina el color de los textos flotantes sobre el menu

  // muestra info si el cursor esta sobre la X del menu

    if(((mouseX > ( mx-30))&&(mouseY > (my-30)))&&((mouseX < (mx+30))&&(mouseY < (my+30))))
  {
    text("Close",mx,my);
    return;
  }
  //------------------------------------------------------------

  // muestra info si el cursor esta sobre el boton 1 del menu

  xb1=mx;
  yb1=my-145;

  if(((mouseX > ( xb1-54))&&(mouseY > (yb1-54)))&&((mouseX < (xb1+54))&&(mouseY < (yb1+54))))
  {
    text("HELP",xb1-12,yb1-50);
    return;
  }
  //------------------------------------------------------------  

  // muestra info si el cursor esta sobre el boton 2 del menu

  xb2=mx-130;
  yb2=my-60;

  if(((mouseX > ( xb2-52))&&(mouseY > (yb2-52)))&&((mouseX < (xb2+52))&&(mouseY < (yb2+52))))
  {
    text("EXPORT",xb2-30,yb2-50);
    return;
  }
  //------------------------------------------------------------

  // muestra info si el cursor esta sobre el boton 3 del menu

  xb3=mx-130;
  yb3=my+80;

  if(((mouseX > ( xb3-54))&&(mouseY > (yb3-54)))&&((mouseX < (xb3+54))&&(mouseY < (yb3+54))))
  {
    text("TEXTURE",xb3-27,yb3-53);
    return;
  }
  //------------------------------------------------------------

  // muestra info si el cursor esta sobre el boton 4 del menu

  xb4=mx;
  yb4=my+140;

  if(((mouseX > ( xb4-54))&&(mouseY > (yb4-54)))&&((mouseX < (xb4+54))&&(mouseY < (yb4+54))))
  {
    text("PATTERN",xb4-24,yb4-48);
    return;
  }
  //------------------------------------------------------------

  // muestra info si el cursor esta sobre el boton 5 del menu

  xb5=mx+120;
  yb5=my+85;

  if(((mouseX > ( xb5-52))&&(mouseY > (yb5-52)))&&((mouseX < (xb5+52))&&(mouseY < (yb5+52))))
  {
    text("3D OBJECT",xb5-18,yb5-50);
    return;
  }
  //------------------------------------------------------------

  // muestra info si el cursor esta sobre el boton 6 del menu

  xb6=mx+120;
  yb6=my-60;

  if(((mouseX > ( xb6-52))&&(mouseY > (yb6-52)))&&((mouseX < (xb6+52))&&(mouseY < (yb6+52))))
  {
    text("RUN",xb6-23,yb6-52);
    return;
  }
  //------------------------------------------------------------


}



//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


public void entrada()
{

image(logo,(screen.width/2)-286, (screen.height/2)-191);
delay(3000);  
mlogo=0;
}


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

public void draw() 
{

  // borra pantalla

  background(255,255,255);
  fill(256,0,0);
  noStroke();
  fill(255, 255, 255);
  rect(0,0,screen.width,screen.height);
  stroke(255);

//dibuja cuadricula

 stroke(220);
//dibuja lineas horizontales
  for(int i=0;i<height;i=i+inc){
    line(x, y+i,width , y+i);
  }

//dibuja lineas verticales
  for(float i=0;i<width;i=i+inc){
    line(x+i, y,x+i , height);
  }

// carga el mapa
  minfo = loadStrings("mapainfo.txt");
  nima=PApplet.parseInt(minfo[0]);
  
// Muestra el logo si entrada es igual a 0
  if(mlogo==1)entrada();
//-----------------------------

// dibuja el mapa
  for( int i=1; i<nima;i=i+3)
  {
    imagen = loadImage(minfo[i]);
    xima=PApplet.parseInt(minfo[i+1]);
    yima=PApplet.parseInt(minfo[i+2]);
    image(imagen,xima+pbx,yima+pby,imagen.width/1, imagen.height/1);
  } 
//-----------------------------
 
  fill(255,0,0);
  text(object3d, 160, 138); // MUSTRA EL NOMBRE DEL OJBJETO 3D 
  text(pattern, 160, 288); // MUSTRA EL NOMBRE DEL MARCADOR 
  text(modelsize, 160, 438);
  text(speed, 160,588);
// Muestra el menu si mm es igual a 1
  if(mm==1)menu();
  //-----------------------------


// Muestra el logo si entrada es igual a 0
  if(mhelp==1)help();
//-----------------------------
    


}// FIN del Draw


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



public void mousePressed() {
mhelp=0;
  if(click ==0){
    click=-1;
  }
  else if(click ==1)click=0; 
  else click=click*-1;

  //si el menu no esta acivo lo activa y se sale de mousePresed
  if(inicio==0){
    mm=1;
    mx=mouseX;
    my=mouseY;
    inicio=1;
    return;
  }
  //------------------------------------------------------------


  //si el click se hizo fuera del menu, lo desactiva y se sale de mousePresed

  if(!(((mouseX > ( mx-six))&&(mouseY > (my-siy)))&&((mouseX < (mx+six))&&(mouseY < (my+siy)))))
  {
    mm=-1;
    mx=0;
    my=0;
    inicio=0;
    return;
  }
  //------------------------------------------------------------ 


  //*********************************************************************************************
  //*******************************  Clicks dentro del menu  ************************************
  //*********************************************************************************************

  //si el click se hizo la X del menu, lo desactiva y se sale de mousePresed

  if(((mouseX > ( mx-30))&&(mouseY > (my-30)))&&((mouseX < (mx+30))&&(mouseY < (my+30))))
  {
    mm=-1;
    mx=0;
    my=0;
    inicio=0;
    return;
  }
  //------------------------------------------------------------

  //si el click se hizo en INFO (boton 1 del menu), lo desactiva y se sale de mousePresed

  xb1=mx;
  yb1=my-145;

  if(((mouseX > ( xb1-54))&&(mouseY > (yb1-54)))&&((mouseX < (xb1+54))&&(mouseY < (yb1+54))))
  {
    mm=-1;
    mx=0;
    my=0;
    inicio=0;
    mhelp=1;
    //mlogo=1;
    //image(help,(screen.width/2)-286, (screen.height/2)-191);
    return;
  }
  //------------------------------------------------------------

  //si el click se hizo en EXPORT (boton 2 del menu), lo desactiva y se sale de mousePresed

  xb2=mx-130;
  yb2=my-60;

  if(((mouseX > ( xb2-52))&&(mouseY > (yb2-52)))&&((mouseX < (xb2+52))&&(mouseY < (yb2+52))))
  {
    mm=-1;
    mx=0;
    my=0;
    inicio=0;
    //String[] command = { "cmd", "/c", "xcopy", " data\\project ", "C:\\files\\Atomicproject /s/i/y" }; 
    //String[] command = { "cmd", "/c", "xcopy", "data\\project", "data\\project2", "/s/i/y" };
    //Process p = exec(command);
    String folderPath = selectFolder("Seleccione en donde desea exportar el proyecto");  // Opens file chooser
    if (folderPath == null) {
      // If a folder was not selected
      println("No folder was selected...");
    } else {
      // If a folder was selected, print path to folder}
     print(folderPath);
    //String[] command = { "cmd", "/c", "xcopy", "data\\project", "project", "/s/i/y" };
    //String[] command = { "cmd", "/c", "xcopy", "data\\project ", "c:\\files\\Atomicproject /s/i/y" }; 
    String[] command = { "cmd", "/c", "xcopy", "data\\project",""+folderPath+"\\Atomicproject", "/s/i/y" };
    //String[] command = { "/bin/bash", "-c", "cp -R data/project "+folderPath+"/Atomicproject" };
    Process p = exec(command);
    }    
    
/*    
    saveStrings("Data/object_data_vrml", vmrl);
    saveStrings("Wrl/bud_B.dat", objeto);
*/    

    return;
  }
  //------------------------------------------------------------

  //si el click se hizo en TEXTURE (boton 3 del menu), lo desactiva y se sale de mousePresed

  xb3=mx-130;
  yb3=my+80;

  if(((mouseX > ( xb3-54))&&(mouseY > (yb3-54)))&&((mouseX < (xb3+54))&&(mouseY < (yb3+54))))
  {
    mm=-1;
    mx=0;
    my=0;
    inicio=0;
  //mhelp=1;
 // image(help,(screen.width/2)-286, (screen.height/2)-191);
  
                // selecion de la carpeta contenedora de las texturas de objeto 3D 
        
              String texturaurl = selectFolder("Seleccione la capeta de las texturas");  // Opens file chooser
              if (texturaurl == null) {
                // If a folder was not selected
                println("No folder was selected...");
              } else {
                // If a folder was selected, print path to folder

             //lee el nombre del ultimo directorio seleccionado, en el archivo texturefolder.txt             
             //lastex = loadStrings("data/texturefolder.txt");
             //print(latex);
             //print(texturaurl);             
             //textura=lastex[0];
             
             //elimina la carpeta de texturas en la carpeta del proyecto
             String[] command3 = { "cmd", "/c", "rd /s/q data\\project\\images"};
             Process p3 = exec(command3);
             
             splitpath = splitTokens(texturaurl, "\\"); 
             nslash=(splitpath.length)-1; // determina la cantidad de slash en la ruta
             textura = splitpath[nslash]; //se guarda el nombre del directorio seleccionado             
             
             //copia las tecturas objeto 3D en varias carpetas del proyecto
             String[] command5 = { "cmd", "/c", "xcopy",""+texturaurl+"", "data\\project\\models\\"+textura+"", "/s/i/y" };  //copia la carpeta de las texturas en la carpeta models
             Process p5 = exec(command5);             
             String[] command6 = { "cmd", "/c", "xcopy",""+texturaurl+"\\*", "data\\project\\models", "/s/i/y" };  //copia los archivos de textura en la carpeta models
             Process p6 = exec(command6);
             String[] command4 = { "cmd", "/c", "xcopy",""+texturaurl+"\\*", "data\\project\\images", "/s/i/y" };  //copia la carpeta de las texturas en la carpeta del proyecto
             Process p4 = exec(command4);
             
/*             
             //guarda el nombre del ultimo directorio seleccionado, en el archivo texturefolder.txt
             splitpath = splitTokens(texturaurl, "\\"); 
             nslash=(splitpath.length)-1; // determina la cantidad de slash en la ruta
             textura = splitpath[nslash]; //se guarda el nombre del directorio seleccionado
             saveStrings("data/texturefolder.txt", lastex);
*/


    }                 //fin else Seleccione la capeta donde estan las texturas del Objeto 3D
  
    return;
  }
  //------------------------------------------------------------

  //si el click se hizo en PATTERN (boton 4 del menu), lo desactiva y se sale de mousePresed

  xb4=mx;
  yb4=my+140;

  if(((mouseX > ( xb4-54))&&(mouseY > (yb4-54)))&&((mouseX < (xb4+54))&&(mouseY < (yb4+54))))
  {
    mm=-1;
    mx=0;
    my=0;
    inicio=0;
    String loadPath = selectInput("Seleccione el Marcador a Usar");  // Opens file chooser
    if (loadPath == null) {
      // If a file was not selected
      println("No file was selected...");
    } 
    else {
      // If a file was selected, print path to file
/*
      vmrl[5]=loadPath; // carga marcador
      String[] lista2 = splitTokens(loadPath, "/"); 
      nslash=(lista2.length)-1; // determina la cantidad de slash en la ruta
      name2 = lista2[nslash]; //se guarda el nombre del archivo seleccionado
*/

     splitpath = splitTokens(loadPath, "\\"); 
     nslash=(splitpath.length)-1; // determina la cantidad de slash en la ruta
     pattern = splitpath[nslash]; //se guarda el nombre del archivo seleccionado
     xmlconfig[2] ="		<marker>pattern/"+pattern+"</marker>"; // pone en nombre del tattern, en la variable del archivo xml de configuracion.

     String[] command = { "cmd", "/c", "del data\\project\\pattern\\* /s/q" };
     Process p = exec(command);
     
     //copia el marcador en la carpeta del proyecto
     String[] command0 = { "cmd", "/c", "copy",""+loadPath+"","data\\project\\pattern" };
     Process p0 = exec(command0);

    }
        saveStrings("data/project/config.xml", xmlconfig); //escribe el archivo XML en modo TXT
    return;
  }
  //------------------------------------------------------------

  //si el click se hizo en 3D OBJECT (boton 5 del menu), lo desactiva y se sale de mousePresed

  xb5=mx+120;
  yb5=my+85;

  if(((mouseX > ( xb5-52))&&(mouseY > (yb5-52)))&&((mouseX < (xb5+52))&&(mouseY < (yb5+52))))
  {
    mm=-1;
    mx=0;
    my=0;
    inicio=0;
    String loadPath = selectInput("Seleccione el Objeto 3D .dae");  // Opens file chooser
    if (loadPath == null) {
      // If a file was not selected
      println("No file was selected...");
    } 
    else {
      
     // divide en fragmentos la ruta y los guarda en vector de llamado "lista" - el ultimo fragmento es el nombre del archivo
/*
     String[] lista = splitTokens(loadPath, "/"); 
     nslash=(lista.length)-1; // determina la cantidad de slash en la ruta
     name = lista[nslash]; //se guarda el nombre del archivo seleccionado
     objeto[0]=name; // se pone en el apuntador del archivo de objetos el nombre del objeto seleccionado
*/



     splitpath = splitTokens(loadPath, "\\"); 
     nslash=(splitpath.length)-1; // determina la cantidad de slash en la ruta
     object3d = splitpath[nslash]; //se guarda el nombre del archivo seleccionado
     xmlconfig[3] ="		<model>models/"+object3d+"</model>"; // pone en nombre del objeto 3D, en la variable del archivo xml de configuracion.
 
     //vaciar archivos dentro de la carpeta models del proyecto
     String[] command = { "cmd", "/c", "del data\\project\\models\\* /s/q" };
     Process p = exec(command);
     
     //copia el objeto 3D en la carpeta del proyecto
     String[] command2 = { "cmd", "/c", "copy",""+loadPath+"", "data\\project\\models" };
     Process p2 = exec(command2);

     saveStrings("data/project/config.xml", xmlconfig); //escribe el archivo XML en modo TXT            
              
     } //fin else Seleccione el Objeto 3D


    return;
  }
  //------------------------------------------------------------

  //si el click se hizo en RUN (boton 6 del menu), lo desactiva y se sale de mousePresed

  xb6=mx+120;
  yb6=my-60;

  if(((mouseX > ( xb6-52))&&(mouseY > (yb6-52)))&&((mouseX < (xb6+52))&&(mouseY < (yb6+52))))
  {
    mm=-1;
    mx=0;
    my=0;
    inicio=0;
    saveStrings("data/project/config.xml", xmlconfig); //escribe el archivo XML en modo TXT

/*
      command = new String[3];
  command[0] = "/bin/bash";
  command[1] = "-c";
  command[2] = "gnome-terminal"
*/

    String[] command = { "cmd", "/c", "start data\\project\\index.html" };
    Process p = exec(command);
    
    return;
  }
  //------------------------------------------------------------

  //lee guarda la posicion del centro del menu

  //mx=mouseX;
  //my=mouseY;
  //mm=1;
  //------------------------------------------------------------
}// FIN del mousePressed



//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


// Esta funcion cambia la posicion del menu si este es drageado 

public void mouseDragged()
{
  dragged=1;
  mdx=mouseX;
  mdy=mouseY;
  // mueve el background si el click se hizo fuera del menu   
  if(inicio==0)
  {
    //mm=-1;
    //pbx=(mx-mdx)*-1;
    //pby=(my-mdy)*-1;
    //inicio=0;
    return;
  }
  else {
    //------------------------------------------------------------ 

    //si el click se hizo dentro del menu, cambia la posicion del menu
    if(((mouseX > ( mx-six))&&(mouseY > (my-siy)))&&((mouseX < (mx+six))&&(mouseY < (my+siy))))
    {
      //mm=1;
      //mx=0;
      //my=0;
      mx=mouseX;
      my=mouseY;
      //inicio=0;
      return;
    }
    //------------------------------------------------------------ 
  }//fin else

}

public void keyPressed(){

if (key == CODED)
{

if (keyCode == UP) {

  modelsize= modelsize+0.5f;
  xmlconfig[4] ="		<scale>"+modelsize+"</scale>"; // pone el tama\u00f1o del objeto 3D, en la variable del archivo xml de configuracion.
  saveStrings("data/project/config.xml", xmlconfig); //escribe el archivo XML en modo TXT
  
}

if (keyCode == DOWN){

  modelsize= modelsize-0.5f;
  xmlconfig[4] ="		<scale>"+modelsize+"</scale>"; // pone el tama\u00f1o del objeto 3D, en la variable del archivo xml de configuracion.
  saveStrings("data/project/config.xml", xmlconfig); //escribe el archivo XML en modo TXT
  
}

if (keyCode == LEFT){

  speed = speed-0.5f;
  xmlconfig[5] ="		<rotation>"+speed+"</rotation>"; // pone la velocidad de rotacion, en la variable del archivo xml de configuracion.
  saveStrings("data/project/config.xml", xmlconfig); //escribe el archivo XML en modo TXT
  
}

if (keyCode == RIGHT){

  speed= speed+0.5f;
  xmlconfig[5] ="		<rotation>"+speed+"</rotation>"; // pone la velocidad de rotacion, en la variable del archivo xml de configuracion.        
  saveStrings("data/project/config.xml", xmlconfig); //escribe el archivo XML en modo TXT
  
}

}

} 



//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++





  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#f0f0f0", "ATOMICWEB04windows" });
  }
}
